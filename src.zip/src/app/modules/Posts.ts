//import { Users } from './Users';

export class Posts{

    userId:number;
    id:number;
    title: string;
    body:string; 


}