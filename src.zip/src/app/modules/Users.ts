import{Address} from './Address';

export class Users{

id:number;
name: string;
username:string;
email: string;
address:Address;


}